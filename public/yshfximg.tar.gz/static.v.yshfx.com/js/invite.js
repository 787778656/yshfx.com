$(function(){
    $(".inviteBtn").click(function(){
        $(".confirmAlert").show();
    });
    $(".confirm_close").click(function(){
        $(".confirmAlert").hide();
    })
});
